package com.example.aplikasilogin;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;


public class ManageAccount extends AppCompatActivity {
    EditText edEmail, edUsername, edPassword, edUlangPassword;
    Spinner spRole;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_account);
        edEmail = findViewById(R.id.ed_email);
        edUsername = findViewById(R.id.ed_username);
        edPassword = findViewById(R.id.ed_password);
        edUlangPassword = findViewById(R.id.ed_ulangpassword);
        spRole = findViewById(R.id.sp_role);
        progressBar = findViewById(R.id.progress_bar);

        progressBar.setVisibility(View.INVISIBLE);

    }

    public void onCreateAccount (View view){
        String email = edEmail.getText().toString();
        String password = edPassword.getText().toString();
        String ulangPassword = edUlangPassword.getText().toString();
        String username = edUsername.getText().toString();
        String role = spRole.getSelectedItem().toString();

        if(email.isEmpty() || password.isEmpty() || ulangPassword.isEmpty() || username.isEmpty() || role.isEmpty()){
            Toast.makeText(this, "Semua field wajib diisi", Toast.LENGTH_LONG).show();
        } else {
            progressBar.setVisibility(View.VISIBLE);
            createAccount(email, username, password, role);
        }
    }

    private void createAccount (String email, String username, String password, String role) {

        AndroidNetworking.post(Endpoint.CREATE_LOGIN)
                .addBodyParameter("email", email)
                .addBodyParameter("username", username)
                .addBodyParameter("password", password)
                .addBodyParameter("role", role)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response){
                        progressBar.setVisibility(View.INVISIBLE);
                        Log.d("ManageAccount", "Create Account :" + response);
                        try {
                            String result = response.getString("message");
                            if (result.contains("login data successfully added")){
                                new AlertDialog.Builder(ManageAccount.this)
                                        .setMessage("Berhasil Menambahkan Data !")
                                        .setCancelable(false)
                                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                                edEmail.getText().clear();
                                                edUsername.getText().clear();
                                                edPassword.getText().clear();
                                                edUlangPassword.getText().clear();
                                            }
                                        })
                                        .show();
                            } else if (result.contains("required field is empty")){
                              progressBar.setVisibility(View.INVISIBLE);
                              new AlertDialog.Builder(ManageAccount.this)
                                      .setMessage("Gagal Menambahkan Data!")
                                      .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                          @Override
                                          public void onClick(DialogInterface dialog, int which) {
                                              dialog.dismiss();
                                          }
                                      })
                                      .setCancelable(false)
                                      .show();
                            }
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError anError){
                        Log.d("ManageAccount", "Create Account :" + anError.getErrorBody());
                    }
                });
    }
}
