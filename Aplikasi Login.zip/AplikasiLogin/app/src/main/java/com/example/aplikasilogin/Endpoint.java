package com.example.aplikasilogin;

public class Endpoint {
    private static final String BASE_URL ="http://192.168.245.238/aplikasilogin/";
    public static final String CEK_LOGIN = BASE_URL+"cek_login.php";
    public static final String CREATE_LOGIN = BASE_URL + "create_login.php";
}
